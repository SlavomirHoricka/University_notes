# Vault map

Snapshot: 2026-10-02. Paths are relative to the vault root. This is an orientation aid, not a learning or mastery assessment.

## Layout

- `00_Materials/`: original sources, mostly PDFs; uses `Year_1`, `Year_2`, etc. Discover course mappings by code/name rather than assuming the year labels match notes.
- `01_Notes/<academic_year>/<semester>/<course>/`: Markdown notes and occasional assets.
- `02_Resources/`: shared resources; renamed from `03_Resources/`. Currently has no course hierarchy.
- `03_Agents/<academic_year>/<semester>/<course>/`: mirrors all existing course directories under `01_Notes/`; ready for course plans and logs. No learner state has been inferred.

## Course inventory

| Course path under 01_Notes and 03_Agents | Markdown files | Hub candidates |
|---|---:|---|
| `2024_2025/Summer_Semester/JEB004_Ekonomie_II` | 0 | None found |
| `2024_2025/Summer_Semester/JEB006_Matematika_II` | 0 | None found |
| `2024_2025/Summer_Semester/JEB024_Základy_Soukromého_Práva` | 0 | None found |
| `2024_2025/Summer_Semester/JEB046_Účetnictví_I` | 0 | None found |
| `2024_2025/Summer_Semester/JEB059_Seminář_Matematické_Analýzy_a_Algebry_II` | 0 | None found |
| `2024_2025/Summer_Semester/JEB104_Microeconomics_I` | 18 | `JEB104_Microeconomics_I_Master.md` |
| `2024_2025/Summer_Semester/JEB142_Introductory_Statistics` | 18 | `JEB142_Introductory_Statistics_Master.md` |
| `2024_2025/Summer_Semester/JLB004_Angličtina_pro_Ekonomy_II` | 0 | None found |
| `2024_2025/Summer_Semester/JPB198_Úvod_do_Politologie` | 0 | None found |
| `2024_2025/Winter_Semester/JEB005_Matematika_I` | 0 | None found |
| `2024_2025/Winter_Semester/JEB023_Úvod_do_Studia_Práva` | 0 | None found |
| `2024_2025/Winter_Semester/JEB055_Seminář_k_Aktualitám_I` | 0 | None found |
| `2024_2025/Winter_Semester/JEB058_Seminář_Matematické_Analýzy_I` | 0 | None found |
| `2024_2025/Winter_Semester/JEB101_Principles_of_Economics_I` | 0 | None found |
| `2024_2025/Winter_Semester/JEB111_Advanced_Data_Analysis_in_MS_Excel` | 0 | None found |
| `2024_2025/Winter_Semester/JLB003_Angličtina_pro_Ekonomy_I` | 0 | None found |
| `2025_2026/Summer_Semester/JEB010_Makroekonomie_II` | 14 | `JEB010_Makroekonomie_II_Master.md` |
| `2025_2026/Summer_Semester/JEB029_Matematika_IV` | 0 | None found |
| `2025_2026/Summer_Semester/JEB050_International_Finance` | 13 | `JEB050_International_Finance_Master.md` |
| `2025_2026/Summer_Semester/JEB109_Econometrics_I` | 17 | `JEB109_Econometrics_I_Master.md` |
| `2025_2026/Summer_Semester/JEB154_Bachelors_Thesis_Seminar_I` | 0 | None found |
| `2025_2026/Summer_Semester/JEB160_Auctions_and_Game_Theory` | 0 | None found |
| `2025_2026/Winter_Semester/JEB009_Makroekonomie_I` | 13 | `JEB009_Makroekonomie_I_Master.md` |
| `2025_2026/Winter_Semester/JEB027_Finanční_Ekonomie` | 25 | `JEB027_Financni_Ekonomie_Master.md` |
| `2025_2026/Winter_Semester/JEB033_Matematika_III` | 0 | None found |
| `2025_2026/Winter_Semester/JEB044_Financial_Accounting` | 17 | `JEB044_Financial_Accounting_Master.md` |
| `2025_2026/Winter_Semester/JEB105_Statistics` | 43 | `JEB105_Statistics_Master.md` |
| `2025_2026/Winter_Semester/JEB108_Microeconomics_II` | 19 | `JEB108_Microeconomics_II_Master.md` |
| `2025_2026/Winter_Semester/JEB157_Data_Analysis_in_R` | 0 | None found |
| `2026_2027/Winter_Semester/Behavioral_Economics` | 0 | None found |
| `2026_2027/Winter_Semester/Comparative_Economics` | 0 | None found |
| `2026_2027/Winter_Semester/Econometrics_II` | 0 | None found |
| `2026_2027/Winter_Semester/Economics_of_Green_Deal` | 0 | None found |
| `2026_2027/Winter_Semester/Financial_Markets_Instruments_I` | 0 | None found |
| `2026_2027/Winter_Semester/JEM231_-_Mergers_and_Acquisitions` | 4 | `Main_-_Mergers_and_Acquisitions.md` |

## File counts

- `00_Materials`: 298 .pdf, 1 .xlsx
- `01_Notes`: 201 .md, 99 .png
- `02_Resources`: 2 .md

## Observations and boundaries

- No `AGENTS.md`, `SKILL.md`, or teaching-skill file was found in this vault. The original skill must be supplied in the next chat.
- Hub names vary: `Main_-_Mergers_and_Acquisitions.md` and `*_Master.md` exist; do not require a literal `*_main.md` suffix.
- Sampled hubs contain ordinary Obsidian `[[wikilinks]]` and `![[image embeds]]`; resolve relative paths, aliases, headings and duplicate filenames deliberately.
- Existing examples include space/underscore mismatches: `[[shareholder activist]]` versus `shareholder_activist.md`, and image embed names with spaces versus filenames with underscores. These predate preparation; report unresolved links rather than silently rewriting them.
- The resource rename was verified by comparing SHA-256 hashes of all moved files. A pre-rename text search found no `03_Resources` references in vault text/config files.
- Notes and learning-source content were not edited. No learning sessions, assessments or research were performed.
- Empty courses have directories but no plan/log. Create substantive plans only after inspecting a selected course; create logs only with explicitly unassessed state or actual session evidence.
- This map does not prove source freshness. The teaching skill must establish and compare its own per-course source manifests at runtime.
