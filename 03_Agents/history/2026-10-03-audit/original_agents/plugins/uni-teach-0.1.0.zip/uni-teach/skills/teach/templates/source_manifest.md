# Source manifest — TEMPLATE, not an established baseline

Use with [the freshness protocol](../references/RECORDS.md); fix the link when copying into a course. A hash establishes byte identity, not truth, relevance, or comprehension. No source baseline has been collected in this template.

- schema_version: 1
- course_id: null
- timezone: Europe/Prague
- record_revision: 0
- transaction_id: null
- current_source_version: null
- baseline_established_at: null
- historical_changes_before_baseline: unknown

## Watch scope

- notes_directory: null
- materials_directory: null
- hub: null
- additional_watched_directories: []
- additional_shared_or_cross_course_files: []
- external_sources: []
- scope_rationale: null
- excluded: agent state, backups, hidden app configuration, unrelated courses
- known_unresolved_links: []
- unresolved_anchors_or_ambiguities: []
- coverage_limits: null

## Immutable snapshots

No snapshots yet. Append a block at each new source version, preserving earlier rows and semantic baselines. File inventory and byte hashing need not load every source's content into the conversation. Hash binary attachments too, while recording what was actually inspected.

```yaml
source_version: <V001>
captured_at: <actual ISO 8601 timestamp with offset>
timezone: Europe/Prague
transaction_id: <checkpoint transaction ID>
previous_source_version: null
enumeration_complete_for_watch_scope: false
enumeration_errors: []
entries:
  - path: <exact vault-relative filename>
    kind: <markdown|pdf|image|spreadsheet|other>
    role: <teaching_source|candidate_uninspected|out_of_scope>
    sha256: null # full raw-byte hash, or null plus reason
    bytes: null
    modified_at: null
    hash_error: null
    inspected_at: null
    inspection_coverage: <sections/pages/figures or uninspected>
    objective_ids: []
    relevant_links: [] # original target, resolved path/anchor or gap
    semantic_baseline: null # claims, assumptions, formulas, expected scope
    baseline_limits: null
    previous_path: null
    change_class: <initial|unchanged|formatting_only|path_only|new_content|substantive_correction|deleted|uncertain>
    change_reason: null
    previous_hash: null
    affected_objective_ids: []
    reassessment_required: null
    reconciliation_event_id: null
```

Record deleted entries as tombstones in the new snapshot, with previous hash/path; keep prior snapshots. For external pages add URL, retrieval time, captured content hash/digest and inspection limits; do not claim remote freshness from the local file hash. Dated reconciliation summaries belong to the log and are referenced here, not duplicated as another current-state summary.
