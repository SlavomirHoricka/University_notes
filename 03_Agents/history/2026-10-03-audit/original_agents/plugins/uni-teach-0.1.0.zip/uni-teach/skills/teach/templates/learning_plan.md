# Learning plan — TEMPLATE, not a learner record

Copy only when a course is selected; replace this title and placeholders. Do not create sessions or outcomes from the template. Shared instructions: [teach](../SKILL.md) and [record protocol](../references/RECORDS.md). **When copied into a course, replace these links with the correct relative links to `03_Agents/teach/`.**

- schema_version: 1
- course_id: null
- course_code: null
- course_title: null
- hub: null
- notes_directory: null
- materials_directory: null
- shared_instructions: null
- created_at: null
- updated_at: null
- timezone: Europe/Prague
- record_revision: 0
- transaction_id: null
- plan_version: P001
- source_version: null
- plan_scope: null
- requested_outcome: null
- deadline_or_retention_horizon: null
- syllabus_coverage: unknown
- plan_status: provisional

## Coverage and source uncertainty

Link the source manifest and distinguish required syllabus content, available material, inspected sections, and missing/unreadable sources. Cite contradictory claims with their locations. Source availability is not learner knowledge.

## Sequence and rationale

List objective IDs in a provisional learning order with reasons and prerequisite dependencies. State why each prerequisite is necessary. Cross-course references must include the other course's identity and relevant evidence conditions. Navigation links alone do not establish dependencies.

## Objectives

No objectives yet. Add this block for each source-grounded objective; reuse its ID through revisions that preserve its identity. New or substantially split/merged objectives need new IDs and explicit predecessor mappings.

```yaml
objective_id: <O001>
objective_revision: 1
criterion_version: <O001-C1>
action_content_conditions: <observable goal, not just 'understand'>
knowledge_types: [] # factual, conceptual, procedural, metacognitive as applicable
bloom_processes: [] # alignment descriptors, not a learner score
sources: [] # exact paths and page/heading, source version
content_and_assumption_digest: null
prerequisites: [] # qualified IDs plus rationale, or explicit unassessed prerequisite
assessment_criteria:
  essential_components: []
  acceptable_alternatives: []
  critical_errors: []
  allowed_tools_and_notes: null
  advancement_rule: <default two distinct unaided checks; explain any adjustment>
assessment_forms:
  immediate: null
  delayed: null
  transfer: null
learning_status: unassessed
retention_status: untested
reassessment_gate: clear
gate_reason: null
evidence_event_ids: []
evidence_criterion_version: null
evidence_limits: null
retention_interval_observed: null
retired_at: null
```

## Plan revisions

No revisions recorded. Append dated old/new plan and criterion versions, source-change event IDs, objective mappings, reasons, and preserved old objective/criteria digests. Keep sufficient old definitions to interpret earlier results. Routine status updates cite events without rewriting this history. Current session position belongs only in the log.
