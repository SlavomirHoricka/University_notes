# Learning log — TEMPLATE, not a learner record

No learning has been recorded in this template. On copying, set course identity, fix the [protocol link](../references/RECORDS.md) for the destination, and replace this title. Do not copy the schema blocks below as events.

- schema_version: 1
- course_id: null
- timezone: Europe/Prague
- record_revision: 0
- transaction_id: null

## Current state

- updated_at: null
- session_id: null
- session_status: not_started
- session_started_at: null
- time_budget_minutes: null
- began_at_objective_and_step: null
- plan_version: null
- source_version: null
- requested_scope: null
- resolved_week_and_evidence: null
- last_committed_event_id: null
- last_completed_step: null
- stopped_at: null
- pending_attempt_id: null
- next_intended_step: null
- position_in_plan: null
- time_deferred_objective_ids: []
- unresolved_misconception_event_ids: []
- pending_reassessment_objective_ids: []
- blockers_or_uncertainty: null

## Chronological events — append only

No events. Append actual events with unique heading IDs. Use ISO 8601 timestamps with the correct local offset and `Europe/Prague`; leave genuinely unavailable values `null`.

## Schema reference — not events

Remove this reference section from a live log if it becomes distracting; the shared protocol remains authoritative.

```yaml
event_id: <unique event ID>
transaction_id: <checkpoint transaction ID>
recorded_at: <actual ISO 8601 timestamp with offset>
occurred_at: null
timezone: Europe/Prague
writer: <agent or human identifier>
role: tutor
type: attempt_result
session_id: <existing session ID>
plan_version: <P001>
source_version: <V001>
attempt_id: <existing attempt ID>
objective_ids: []
criterion_versions: []
phase: <diagnostic|initial_learning|immediate_practice|delayed_retrieval|reassessment>
purpose: null
task_ref: null
task_text_or_digest: null
item_version: null
task_relation: unknown
changed_task_features: null
criteria: []
response_evidence: null
outcome: <met|partial|not_met|incomplete|unscorable>
score: null
score_denominator: null
assistance: unknown
hints: []
note_access: unknown
tools_used: null
solution_exposure: unknown
confidence_before_feedback: null
errors_or_misconceptions: []
feedback: null
feedback_at: null
next_need: null
previous_attempt_id: null
last_relevant_exposure_at: null
intervening_exposure: unknown
proposal_id: null
supersedes_event_id: null
```

Other event types use the common fields and relevant payload only. `attempt_started` records the item and criterion before presentation; `instruction_or_feedback` records actual exposure; `commit` lists the transaction and resulting file revisions. Do not treat a start as an outcome or a transaction as committed until its commit event exists.

For `session_plan`, use the common event fields plus `time_budget_minutes` (learner-reported or `null`), `requested_scope`, `candidate_objective_ids`, `ordered_selected_objective_ids`, `time_deferred_objective_ids` for new time deferrals, and `priority_reasons_by_objective_id`. Append `session_plan_update` when the selection changes, with `supersedes_event_id` and the reason. The current-state time-deferred IDs combine earlier unstudied time deferrals with new ones; remove an ID only after actual study or an explicit scope decision recorded in an event. These IDs are not assessment outcomes. An existing live log can add the two current-state fields at the next checkpoint without rewriting past events.

Scheduler-only optional payload, also append-only:

```yaml
event_id: <unique event ID>
transaction_id: <checkpoint transaction ID>
recorded_at: <actual ISO 8601 timestamp with offset>
occurred_at: null # no learning event occurred
timezone: Europe/Prague
writer: <scheduler identifier>
role: scheduler
type: schedule_proposal
session_id: null
proposal_id: <unique proposal ID>
plan_version: null
source_version: null
criterion_versions: []
objective_ids: [] # fully qualified course/objective IDs
supporting_event_ids: []
planned_review_date_or_window: null
planned_task_type: null
priority: null
rationale: null
proposal_state: proposed
supersedes_proposal_id: null
```
