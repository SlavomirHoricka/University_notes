# Uni Teach

Private, skills-only plugin based on Slavomir Horicka’s maintained `teach` skill.

## Use

Install the private plugin in Codex and use it in the Uni workspace. Select a course, week folder, note, or topic and say “Use Uni Teach to teach this material; I have 30 minutes.” For revision, ask to revise the selected topic. For continuation, ask to resume the selected course from its recorded learning.

The skill checks the study time budget, teaches in short cycles, waits for one answer at a time, and records observed learning separately from retention. It reads course notes to choose objectives and checks source changes before relying on earlier assessments.

## Local requirements

The host must be able to read `/Users/slavomirhoricka/Desktop/Obsidian/Uni` and write that vault’s `03_Agents/<year>/<semester>/<course>/` records. Open the Uni workspace in Codex for the intended workflow. The package supplies instructions, references, and blank templates; it supplies no filesystem server. Installing it in a host without local file access does not expose the vault. If access is unavailable, report that limitation and request usable material; do not claim to read or save course records.

Course notes, original materials, vault navigation files, and existing learner records remain local and are not included in the uploaded package. `Europe/Prague` remains the teaching timezone. Review proposals in the record do not create notifications or an automation.

## Source and updates

Canonical source: `/Users/slavomirhoricka/Desktop/Obsidian/Uni/03_Agents/teach/`, also registered through `~/.agents/skills/teach`.

The bundled six Markdown files are an unchanged snapshot of that source. Edit the canonical source, then rebuild and release the plugin with a new version; installed copies do not synchronize automatically. When invoking this plugin, use its bundled references and templates consistently for the session. The original standalone skill remains installed.

`plugin.json` is the portable Agent Plugins manifest. `.codex-plugin/plugin.json` is the synchronized Codex compatibility manifest. No MCP server or app dependency is required.
